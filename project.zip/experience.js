
import { escapeHtml as escape } from '../utils/html.js';
import { renderTech } from '../utils/tech-icons.js';

export function renderExperience(experience) {
  const container = document.getElementById('experience-content');
  if (!container) return;
  container.innerHTML = `
    <div class="experience-aside">
      <div class="experience-brand">
        <span class="company-logo"><img src="${escape(experience.logo)}" alt="" width="32" height="32" loading="lazy"></span>
        <span class="experience-company">${escape(experience.company)}</span>
      </div>
      <p>${escape(experience.role)}<br>${escape(experience.location)}</p>
      <div class="experience-tools mono">
        ${experience.tools.map(row => `<div class="experience-tool-line">${row.map(renderTech).join('')}</div>`).join('')}
      </div>
    </div>
    <div class="experience-main">
      <h3>${experience.heading.map(escape).join('<br>')}</h3>
      <p>${escape(experience.description)}</p>
      <div class="experience-points">
        ${experience.points.map((point, index) => `
          <div><span class="point-index mono">${String(index + 1).padStart(2, '0')}</span>
            <div><h4>${escape(point.title)}</h4><p>${escape(point.description)}</p></div>
          </div>`).join('')}
      </div>
    </div>`;
}
